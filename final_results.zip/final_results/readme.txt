All of the results that were used in the final version of the project file.
Other zip folders contain the entirety of the testing procedure, including the development phase, but this folder has only the good stuff
