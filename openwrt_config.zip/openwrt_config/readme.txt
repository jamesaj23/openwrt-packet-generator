This is the state of all the config files on the OpenWrt device at the time of submission.

The files of importance are:
	`qos`
	`wireless`
	`network`
	`opkg`

The rest are irrelevant/at default settings anyway.